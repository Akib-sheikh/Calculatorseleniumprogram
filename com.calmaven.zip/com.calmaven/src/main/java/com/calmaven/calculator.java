package com.calmaven;

public class calculator {
	
	
  public int add(int n1, int n2) 
  { 
	  System.out.println(n1+n2);
	  return n1+n2; 
  }
	 
  public int sub(int n1, int n2)
  {
	  System.out.println(n1-n2);
	  return n1-n2;
  }
  public int mul(int n1, int n2)
  {
	  System.out.println(n1*n2);
	  return n1*n2;
  }
  public double div(double n1, double n2)
  {
	  if(n2==0)
	  {
		  throw new IllegalArgumentException("Number cannot be divided by 0!");
	  }
	  System.out.println(n1/n2);
	  return n1/n2;
  }
  
  public static void main(String[] args)
  {
	  calculator cl = new calculator();
	  cl.add(-234234, 345345);
	  cl.sub(234823, -23094823);
	  cl.mul(423, 525);
	  cl.div(4000, 200);
	  
  }

}
