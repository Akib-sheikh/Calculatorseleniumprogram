package com.calmaven.test;

//import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Calculator1 {

	WebDriver driver;

	@BeforeMethod
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.calculator.net/");
	}

	@Test
	public void mulcheck() throws InterruptedException {

		// MULTIPLICATION OF TWO NUMBERS
		WebElement four = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four.click();
		WebElement two = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two.click();
		WebElement three = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three.click();
		WebElement multiply = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[4]"));
		multiply.click();
		WebElement five = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]"));
		five.click();
		WebElement tw = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		tw.click();
		WebElement fv = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]"));
		fv.click();
		Thread.sleep(2000);

	}

	// ADDITION OF TWO NUMBER
	@Test
	public void addcheck() throws InterruptedException {

		WebElement minus = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[4]"));
		minus.click();
		WebElement two1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two1.click();
		WebElement three1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three1.click();
		WebElement four1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four1.click();
		WebElement two2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two2.click();
		WebElement three2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three2.click();
		WebElement four2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four2.click();
		WebElement plus = driver.findElement(By.className("sciop"));
		plus.click();
		WebElement three3 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three3.click();
		WebElement four3 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four3.click();
		WebElement five2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[2]"));
		five2.click();
		Thread.sleep(2000);

	}

	// SUBTRACTION OF TWO NUMBERS
	@Test
	public void subcheck() throws InterruptedException {

		WebElement two = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two.click();
		WebElement three = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three.click();
		WebElement four = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four.click();
		WebElement eight = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[1]/span[2]"));
		eight.click();
		WebElement two1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two1.click();
		WebElement three1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three1.click();
		WebElement minus = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[2]/span[4]"));
		minus.click();
		WebElement two2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two2.click();
		WebElement three2 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three2.click();
		WebElement zero = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero.click();
		WebElement nine = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[1]/span[3]"));
		nine.click();
		WebElement four1 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four1.click();
		WebElement eight1 = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[1]/span[2]"));
		eight1.click();
		WebElement two3 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two3.click();
		WebElement three3 = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[3]"));
		three3.click();
		Thread.sleep(2000);

	}

	// DIVISION OF TWO NUMBERS
	@Test
	public void divcheck() throws InterruptedException {

		WebElement four = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[2]/span[1]"));
		four.click();
		WebElement zero = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero.click();
		WebElement zero1 = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero1.click();
		WebElement zero2 = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero2.click();
		WebElement div = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[4]"));
		div.click();
		WebElement two = driver.findElement(By.xpath("//*[@id=\"sciout\"]/tbody/tr[2]/td[2]/div/div[3]/span[2]"));
		two.click();
		WebElement zero3 = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero3.click();
		WebElement zero4 = driver.findElement(
				By.xpath("/html/body/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/div/div[4]/span[1]"));
		zero4.click();
		Thread.sleep(2000);

	}

	@AfterMethod
	public void teardown() {
		driver.close();
	}

	public static void main(String[] args) throws InterruptedException {
		Calculator1 a = new Calculator1();
		a.setup();
		a.addcheck();
		a.mulcheck();
		a.subcheck();
		a.divcheck();
		a.teardown();

	}
}
